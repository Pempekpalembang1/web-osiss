**THIS MESSAGE IS DEFINITELY NOT MEANT TO BE READ BY THE PUBLIC.  
IF YOU WANT TO PUSH CHANGES TO NETLIFY, YOU MUST MAKE THIS REPOSITORY PUBLIC, THEN YOU CAN PRIVATE IT LATER.  
(harus kamu buka private dulu baru push changes.)**

# Website OSIS SMAN 8 Semarang

<img src="https://media1.tenor.com/m/EfXDj90ApuYAAAAd/cursu-dreamybull.gif" alt="Alamak!" width="500" height="250">

😂😂😂😂😂😂😂😂😂😂

## Teknologi yang Digunakan

- **JavaScript**: Vite (React)
- **CSS**: TailwindCSS
- **Animasi**: AOS
- **Web Hosting**: Netlify

## Menurunkan Kepengurusan ke Periode Selanjutnya

Jadi sebenernya akun utama OSIS itu kuubah jadi organisasi dan ternyata gak bisa dibalikin😂. (Gapapa lah biar jadi badge💀), Jadi kalian kalau mau nambahin diri kalian jadi member organisasi tinggal login akun (.github), trus invite aja. Kalau kalian gapeduli tentang ngepush update dari akun pribadi kalian ya berarti kalian gak usah invite sama sekali.

Akun GitHub sama Netlify pake yang akun (.github), kalo google search console tetep pake akun utama.

<img src="https://media1.tenor.com/m/o_hNDSl9gbMAAAAd/dreamybullcoldestmoment.gif" alt="Ambatron!" width="500" height="250">

## Saran (kalo mau)

Sebenernya kalo kamu cuma mau ganti-ganti teks/gambar gaperlu tahu terlalu detail si

1. Paling engga pelajarilah dulu Git, npm, React.
2. Kalo mau ngubah pelajari Tailwind, Responsive Web Design, Grid vs. Flex, Padding vs. Margin, % vs px, Positioning, dll.
3. Kalo nambah fitur selalu bikin dokumentasi juga, biar ga bingung kalo lihat kode lagi.
4. Jangan berharap banyak sama figma to code😂
5. Kalo kamu nanya gimana caranya ngubah-ngubah gambar/teks doang, baca lagi no.1😂

Kalo mau cari tutorial yang agak singkat coba deh Traversy Media, kalo mau yang panjang coba lihat FreeCodeCamp. Coba tonton aja vidoe Traversy media yang Git sama yang React.

<img src="https://media1.tenor.com/m/2a1WioPC3MwAAAAd/dreambully-dreambull.gif" alt="Woila!" width="500" height="250">

## Kontak mungkin?

kalo ada pertanyaan mungkin bisa kontak aku di Instagram, cuma aku buka Instagram paling sebulan sekali😂 jadi ya silahkan dicoba.

1. @tristanozaa

(kalo kamu mau kontribusi nambah namamu silahkan aja)

<img src="https://media1.tenor.com/m/7x4wdZSCH8wAAAAd/the-voices-abatukam.gif" alt="Bisa gila!" width="500" height="250">

(Potret kamu yang gak mencalonkan jadi sekbid 9 dan tiba-tiba masuk, lalu setelah itu dapet tugas melanjutkan proker website😂😂😂)
